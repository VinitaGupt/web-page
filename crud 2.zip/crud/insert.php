<?php
include("config.php");
session_start();
$a_email=$_SESSION['email'];

if(isset($_POST['login'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $number=$_POST['number'];
    
    $sql="select * from employee where emp_email='$email' and admin_email='$a_email'";
  
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        echo"email already exist"; 

    }else{
  
    $sqll= "INSERT INTO employee (emp_name,emp_email,emp_number,admin_email) values('$name','$email','$number','$a_email')";
    // echo $sql;
    // die;
    if(mysqli_query($conn,$sqll))
    {
        echo"success";
    }
    else{
        echo "failed";
    }
    }   
 
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert New Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="index.php">Dashboard</a> 
| <a href="view.php">View Records</a> 
| <a href="logout.php">Logout</a></p>
<div>
<h1>Insert New Record</h1>
<form name="form" method="POST" action=""> 
<p><input type="text" name="name" placeholder="Enter Name"  /></p>
<p><input type="text" name="email" placeholder="Enter email " /></p>
<p><input type="text" name="number" placeholder="Enter Number " /></p>
<p><input type="submit" name="login" value="Submit" /></p>
</form>

</div>
</div>
</body>
</html>