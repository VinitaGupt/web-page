<?php
include "config.php";
session_start();
$a_email=$_SESSION['email'];
$emp_email=$_GET['email'];

$sql="Delete from employee where emp_email='$emp_email' and admin_email='$a_email'";
if(mysqli_query($conn,$sql)){

    header('location:view.php');
    exit();
}
else{
            echo "failed!";
        }

mysqli_close($conn);

?>