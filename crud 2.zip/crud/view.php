<?php
include("config.php");
session_start();
$a_email=$_SESSION['email'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a> 
| <a href="insert.php">Insert New Record</a> 
| <a href="logout.php">Logout</a></p>
<h2>View Records</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>S.No</strong></th>
<th><strong>Name</strong></th>
<th><strong>number</strong></th>
<th colspan="2"><strong>Operations</strong></th>
</tr>
</thead>
<tbody>
<?php

$sql="select * from employee where admin_email='$a_email'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
    ?>
    <tr>
    <td><?php echo $row['emp_name']; ?></td>
    <td><?php echo $row['emp_email']; ?></td>
    <td><?php echo $row['emp_number']; ?></td>
   <td><a href="edit.php?email=<?php echo $row['emp_email'];?>">Update</a></td>
   <td><a href="delete.php?email=<?php echo $row['emp_email'];?>">Delete</a></td>
      
  </tr>

    <?php
  }
}
mysqli_close($conn);
?>
</tbody>
</table>
</div>
</body>
</html>
