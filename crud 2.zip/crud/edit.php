<?php


include "config.php";
session_start();
$a_email=$_SESSION['email'];
$emp_email=$_GET['email'];

if(isset($_POST['edit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $number=$_POST['number'];

    $sql="UPDATE employee SET emp_name='$name', emp_email='$email',emp_number='$number' where emp_email='$emp_email' and admin_email='$a_email' ";
    if(mysqli_query($conn,$sql)){
        // echo "Record Update sucessful";
        header('location:view.php');
        exit();
    }
    else{
                echo "failed!";
            }
    }
    
    mysqli_close($conn);
   ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="index.php">Dashboard</a> 
| <a href="view.php">View Records</a> 
| <a href="logout.php">Logout</a></p>
<div>
<h1>edit Record</h1>

<form name="form" method="POST" action=""> 
<?php
include "config.php";


 $sql="select * from employee where emp_email='$emp_email'  and admin_email='$a_email'";
 $result=mysqli_query($conn,$sql);
 if(mysqli_num_rows($result)>0){
     while($row=mysqli_fetch_assoc($result)){
        
?>
<input type="text" name="name" placeholder="Enter Name" value="<?php echo $row['emp_name']; ?> "/>
<input type="text" name="email" placeholder="Enter email" value=" <?php echo $row['emp_email']; ?> "/>
<input type="text" name="number" placeholder="Enter Number" value="<?php echo $row['emp_number']; ?>" />
<input type="submit" name="edit" value="Submit" /></p>
<?php
     }
    } 

// }
mysqli_close($conn);
?> 
</form>

</div>
</div>
</body>
</html>
