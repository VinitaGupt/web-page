<?php
include "config.php";
session_start(); 
$email=$_SESSION['email'];

$id=$_GET['id'];

 
$sql="update addblog set hidden=1 where id=$id";
if(mysqli_query($conn,$sql)){
    header('location:profile.php');
    exit();
}else{

}



?>