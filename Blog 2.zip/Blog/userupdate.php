
<?php

include "config.php";
session_start();
$uemail=$_SESSION["email"];
$sql="select * from users where email='$uemail'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
   $id=$row['id'];
  }
} 
  

mysqli_close($conn);
if(isset($_POST['submit'])){

    include "config.php";
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $password=$_POST['password'];
    $role=$_POST['role'];
    $uid=$_GET['id'];

    $sql="update users set name='$name',email='$email',mobile='$moblie',password='$password',role='$role' where id= '$uid'";
    if(mysqli_query($conn,$sql)){
        
        echo "user update";
    }else{
        echo "falied";
    }
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="./style.css">
    <style>
        nav{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 100vw;
            height: 7vh;
            background-color: black;
            color: white;
        }
        .left{
            width: 80%;
            height: 100%;
        }
        .left ul{
           padding-right:0%;
           padding-left: 10%;
        }
        .right{
            width: 20%;
            height: 100%;
            display: flex;
            flex-direction: row;
            justify-content: right;
            margin-right: 2%;
        }
        .left a{
            color: white;
        } 
        .right a{
            margin-top: 4%;
            color: white;
            margin-right: 50%;
        }
        nav .left ul li{
            display: inline-block;
            margin-left: 10%;
            flex-direction: row;
            color:white;
        }
        select[type=text]{
        width: 100%;
        padding: 15px;
        margin: 5px 0 22px 0;
        display: inline-block;
        border: none;
        background: #f1f1f1;
}
        select[type=text]:focus {
        background-color: #dddddd;
        outline: none;
}
    </style>
</head>
<body>
    <nav>
    <div class="left">
         
         <ul>
              
              <li><a href="./admin.php">User</a></li>
              <li><a href="./blog.php.php">Blog</a></li>
         </ul>
         </div>
        <div class="right">
        <a href="logout.php">Logout</a>
        </div>
    </nav>
     <div class="container">
        <div class="col-sm-4">
            <form action="" method="post" enctype="multipart/form-data">
                <?php
                $uid=$_GET['id'];
                include 'config.php';
                    $sql="select * from users where id=$uid";
                    
                    $result=mysqli_query($conn,$sql);
                    if(mysqli_num_rows($result)>0){
                      while($row=mysqli_fetch_assoc($result)){

                ?>  
                <div class="col-mb-2">
                <label for="">Name</label>
                <input type="text" name="name" value="<?php echo $row['name'];?>">
                </div>
                <div class="col-mb-2">
                <label for="">Email</label>
                <input type="text" name="email" value="<?php echo $row['email'];?>">
                </div>
                <div class="col-mb-2">
                <label for="">Mobile</label>
                <input type="text" name="mobile" value="<?php echo $row['mobile'];?>">
                </div>
                <div class="col-mb-2">
                <label for="">Password</label><br>
                <input type="text" name="password"  value="<?php echo $row['password'];?>">
                </div>  
                <div class="col-mb-2">
                <label for="">role</label><br>
                <select name="role" type="text">
                 <option value="<?php echo $row['role'];?>">1</option>
                 <option value="<?php echo $row['role'];?>">0</option>
                </select>
                </div>  
                <br>            
                <div class="button">
                <button type="submit" name="submit">Update</button>
                </div>
                <?php
                    }
                } 
                ?>
            </form>
        </div>
     </div>


</body>
</html>