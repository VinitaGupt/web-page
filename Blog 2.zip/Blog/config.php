<?php


$conn=mysqli_connect('localhost','root','','blog');
if(!$conn){
die("Not connected ".mysqli_connect_error());
}
else{

    // echo"connected";
}
?>
