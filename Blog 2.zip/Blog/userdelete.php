<?php
include "config.php";
session_start();
$email=$_SESSION['email'];
$id=$_GET['id'];

$sql="Delete from users where id='$id'";
if(mysqli_query($conn,$sql)){

    header('location:admin.php');
    exit();
}
else{
            echo "failed!";
        }

mysqli_close($conn);

?>