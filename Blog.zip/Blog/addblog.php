
<?php

include "config.php";
session_start();
$uemail=$_SESSION["email"];
$sql="select * from users where email='$uemail'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
   $id=$row['id'];
  }
} 
  

mysqli_close($conn);
if(isset($_POST['submit'])){
 //file upload
 $filename = $_FILES["fileToUpload"]["name"];
 $filename = time() . $filename;
 $tempname = $_FILES["fileToUpload"]["tmp_name"];
 $folder = './uploads/' . $filename;

 // Now let's move the uploaded image into the folder: image
 if (move_uploaded_file($tempname, $folder)) {
//    echo "<h3>  Image uploaded successfully!</h3>";
 } else {
//    echo "<h3>  Failed to upload image!</h3>";
 }

 //represent the database
 $upload_file = './uploads/' . $filename;


    include "config.php";
    $title=$_POST['title'];
    $subject=$_POST['subject'];
    $description=$_POST['description'];
    // $imgname=$_POST['fileupload'];
   

    $sql="insert into addblog(title,subject,description,imgname,uploadedby,hidden)
    values('$title','$subject',' $description','$upload_file','$id',1)";
    if(mysqli_query($conn,$sql)){
        echo "added";
    }else{
        echo "falied";
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="./style.css">
    <style>
        nav{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 100vw;
            height: 7vh;
            background-color: black;
            color: white;
        }
        .left{
            width: 80%;
            height: 100%;
        }
        .left ul{
           padding-right:0%;
           padding-left: 10%;
        }
        .right{
            width: 20%;
            height: 100%;
            display: flex;
            flex-direction: row;
            justify-content: right;
            margin-right: 2%;
        }
        .left a{
            color: white;
        } 
        .right a{
            margin-top: 4%;
            color: white;
            margin-right: 50%;
        }
        nav .left ul li{
            display: inline-block;
            margin-left: 10%;
            flex-direction: row;
            color:white;
        }
       

        
    </style>
</head>
<body>
    <nav>
        <div class="left">
        <ul>
                    <li><a href="./user.php">Home</a></li>
                    <li><a href="./addblog.php">Add Blog</a></li>
                    <li><a href="./profile.php">Profile</a></li>
                </ul>
        </div>
        <div class="right">
        <a href="logout.php">Logout</a>
        </div>
    </nav>
     <div class="container">
        <div class="col-sm-4">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="col-mb-2">
                <label for="">Title</label>
                <input type="text" name="title">
                </div>
                <div class="col-mb-2">
                <label for="">Subject</label>
                <input type="text" name="subject">
                </div>
                <div class="col-mb-2">
                <label for="">Description</label>
                <input type="text" name="description">
                </div>
                <div class="col-mb-2">
                <label for="">img name</label><br>
                <input type="file" name="fileToUpload">
                </div>  
                <br>            
                <div class="button">
                <button type="submit" name="submit">ADD Blog</button>
                </div>
            </form>
        </div>
     </div>


</body>
</html>