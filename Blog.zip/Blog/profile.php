<?php

include "config.php";

session_start(); 
$email=$_SESSION['email'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
    <style>
        nav{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 100vw;
            height: 7vh;
            background-color: black;
            color: white;
           
        }
        .left{
            width: 80%;
            height: 100%;
            /* font-size: 10%; */
        }
        .left ul{
           padding-right:0%;
           padding-left: 10%;
        }
        .right{
            width: 20%;
            height: 100%;
            display: flex;
            flex-direction: row;
            justify-content: right;
            margin-right: 2%;
        }
        .left a{
            color: white;
            /* font-size: larger; */
        } 
        .left ul li a{
            font-size: 16px;
        }
        .right a{
            margin-top: 4%;
            color: white;
            margin-right: 50%;
            font-size: 16px;
        }
        nav .left ul li{
            display: inline-block;
            margin-left: 10%;
            flex-direction: row;
            color:white;
            padding-top: 10px;
            font-size: 10px;
        }
        .container{
            padding:5%;
          
        }
        .operationbtn{
            background-color: #ead;
            padding: 6%;
            border-radius: 5px;
            color: black;
            font-size: larger;
            font-weight: 600;
            text-decoration: none;
        }
        .operationbtn:hover{
            color: white;
            background-color: darkred;
        }
    </style>
</head>
<body>
<nav>
        <div class="left">
         
        <ul>
             <li><a href="./user.php">Home</a></li>
             <li><a href="./addblog.php">Add Blog</a></li>
             <li><a href="./user.php">Profile</a></li>
        </ul>
        </div>
        <div class="right">
        <a href="logout.php">Logout</a>
        </div>
    </nav>
    <?php
   $sql="select * from users where email='$email'";
   $result=mysqli_query($conn,$sql);
   if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
       $id=$row['id'];
    }
   }
   ?>

    <div class=" container">
       <table class="table ">
        <thead class="thead-dark">
       <tr style="text-align: center;">
       <th>Title</th>
            <th>Subject</th>
            <th>Hidden</th>
            <th>Image</th>
            <th colspan="3" >Operations</th>
       </tr>
        </thead>
        <?php
          $sql="select * from addblog  where uploadedby=$id";
          $result=mysqli_query($conn,$sql);
          if(mysqli_num_rows($result)){
            while($row=mysqli_fetch_assoc($result)){
        ?>
            <tr style="text-align: center;"> 
                <td scope="row"><?php echo $row['title'];?></td>
                <td scope="row"><?php echo $row['subject'];?></td>
                <td scope="row"><?php  if($row['hidden']==0){echo "yes";}else{echo "No";} ?></td>
                <td scope="row">
                <img src="<?php echo $row['imgname']?>" alt=""  onclick="enlargeImg()" ondblclick="smallImg()" id="img" height="20px" width="20px"/>
                </td>
                <td><a href="update.php?id=<?php echo $row['id'];?>" class="operationbtn">Update</a></td>
               <td><a href="delete.php?id=<?php echo $row['id'];?>" class="operationbtn">Delete</a></td>
               <?php  
                    if($row['hidden']==0){
                        ?> <td><a href="show.php?id=<?php echo $row['id'];?>" class="operationbtn">Show</a></td>  <?php
                    }
                    else{
                        ?> <td><a href="hide.php?id=<?php echo $row['id'];?>" class="operationbtn">Hide</a></td>  <?php
                    }

                ?>
            </tr>
      <?php
        }
          }
      ?>


       </table>
    </div>


    
</body>
</html>

<script>
        // Get the img object using its Id
        img = document.getElementById("img");
        // Function to increase image size
        function enlargeImg() {
            // Set image size to 1.5 times original
            img.style.transform = "scale(20)";
            // Animation effect
            img.style.transition = "transform 0.25s ease";
        }
        function smallImg() {
            // Set image size to 1.5 times original
            img.style.transform = "scale(1.7)";
            // Animation effect
            img.style.transition = "transform 0.25s ease";
        }
       
    </script>