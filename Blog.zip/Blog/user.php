<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add blog</title>
    <link rel="stylesheet" href="./style.css">
    <style>
        nav{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 100vw;
            height: 7vh;
            background-color: black;
            color: white;
        }
        .left{
            width: 80%;
            height: 100%;
        }
        .left ul{
           padding-right:0%;
           padding-left: 10%;
        }
        .right{
            width: 20%;
            height: 100%;
            display: flex;
            flex-direction: row;
            justify-content: right;
            margin-right: 2%;
        }
        .left a{
            color: white;
        } 
        .right a{
            margin-top: 4%;
            color: white;
            margin-right: 50%;
        }
        nav .left ul li{
            display: inline-block;
            margin-left: 10%;
            flex-direction: row;
            color:white;
        }
        .header{
            padding: 20px;
            margin: 20px;
            height: 10vh;
            text-align: center;
        }
        .leftcolumn{
            float:left;
            width: 50%;
        }
        .rightcolumn{
            float: right;
            width: 20%;
            height: 10vh;
        }
        .card{
            background-color: white;
            padding: 20px;
            margin-top: 20px;
        }
        .img{
            width:100%;
            padding: 20px;
        }
        .section:after{
            content: "";
            display: table;
            clear: both;
        }
        .row{
            font-family: Arial;
            padding: 20px;
            background: #f1f1f1;

        }
        .footer {
         padding: 20px;
         text-align: center;
         background: #ddd;
        margin-top: 20px;
        }
        @media screen and (max-width: 800px) {
       .leftcolumn, .rightcolumn {
        width: 100%;
        padding: 0;
  }
}
        

    </style>
</head>
<body>
    <nav>
        <div class="left">
        <ul>
                    <li><a href="./user.php">Home</a></li>
                    <li><a href="./addblog.php">Add Blog</a></li>
                    <li><a href="./user.php">Profile</a></li>
                </ul>
        </div>
        <div class="right">
        <a href="logout.php">Logout</a>
        </div>
    </nav>
<div class="row">
    <div class="header">
  <h3>Blog</h3>
</div>

<div class="section">
  <div class="leftcolumn">
    <div class="card">
      <h2>TITLE 1</h2>
      <h5>Title description</h5>
      <div class="img">Image</div>
      <p>Some text..</p>
    </div>
    <div class="card">
      <h2>TITLE 2</h2>
      <h5>Title description</h5>
      <div class="img">Image</div>
      <p>Some text..</p>
    </div>
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>About Me</h2>
      <div class="img">Image</div>
      <p>Some text about me in..</p>
    </div>
    <div class="card">
      <h3>Popular Post</h3>
      <div class="img">Image</div><br>
      <div class="img">Image</div><br>
      <div class="img">Image</div>
    </div>
    <div class="card">
      <h3>Follow Me</h3>
      <p>Some text..</p>
    </div>
  </div>
</div>
</div>

<div class="footer">
  <h2>Footer</h2>
</div>

</body>
</html>