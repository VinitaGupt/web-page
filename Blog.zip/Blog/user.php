<?php
session_start(); 
$email=$_SESSION['email'];
include "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add blog</title>
    <link rel="stylesheet" href="./style.css">
 
    <style>
        nav{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 100vw;
            height: 7vh;
            background-color: black;
            color: white;
        }
        .left{
            width: 80%;
            height: 100%;
        }
        .left ul{
           padding-right:0%;
           padding-left: 10%;
        }
        .right{
            width: 20%;
            height: 100%;
            display: flex;
            flex-direction: row;
            justify-content: right;
            margin-right: 2%;
        }
        .left a{
            color: white;
        } 
        .right a{
            margin-top: 4%;
            color: white;
            margin-right: 50%;
        }
        nav .left ul li{
            display: inline-block;
            margin-left: 10%;
            flex-direction: row;
            color:white;
        }
        .header{
            padding: 20px;
            margin: 20px;
            height: 10vh;
            text-align: center;
        }
        .leftcolumn{
            float:left;
            width: 50%;
        }
        .rightcolumn{
            float: right;
            width: 20%;
            height: 10vh;
        }
        .card{
            background-color: white;
            padding: 20px;
            margin-top: 20px;
        }
        .img{
            width:100%;
            padding: 20px;
        }
        .section:after{
            content: "";
            display: table;
            clear: both;
        }
        .row{
            font-family: Arial;
            padding: 20px;
            background: #f1f1f1;

        }
        .footer {
         padding: 20px;
         text-align: center;
         background: #ddd;
        margin-top: 20px;
        }
        @media screen and (max-width: 800px) {
       .leftcolumn, .rightcolumn {
        width: 100%;
        padding: 0;
  }
}     
    </style>
</head>
<body>
    <nav>
        <div class="left">
         
        <ul>
                    <li><a href="./user.php">Home</a></li>
                    <li><a href="./addblog.php">Add Blog</a></li>
                    <li><a href="./profile.php">Profile</a></li>
                </ul>
        </div>
        <div class="right">
        <a href="logout.php">Logout</a>
        </div>
    </nav>
<div class="row">
    <div class="header">
  <h1>Blog</h1>
</div>

<div class="section">
  <div class="leftcolumn">
  
  <?php
 
          $sql="select * from addblog where hidden=1 and violated=1";
          $result=mysqli_query($conn,$sql);
          if(mysqli_num_rows($result)>0){
            while($row=mysqli_fetch_assoc($result)){              
          ?>

    <div class="card">
      <h2><?php echo $row['title'];?></h2>
      <h4><?php echo $row['subject']?></h4>
      <p><?php echo $row['description']?></p>
      <div class="img">
        <img src="<?php echo $row['imgname']?>" alt="" height="300px" width="300px"/>

      </div>
    </div>
   <?php  
  }
}

?>
</div>
  <div class="rightcolumn">
    <div class="card">
      <?php

      $sql="select * from users where email='$email'";
      $result=mysqli_query($conn,$sql);
      if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){
      ?>
      <h2>About Me</h2>
      <p><?php echo $row['name'];?></p> 
      <p><?php echo $row ['email'];?></p>
      <?php
  }
}
?>
    </div>
    <div class="card">
      <?php
      $sql="select * from addblog where hidden=1";
      $result=mysqli_query($conn,$sql);
      if(mysqli_num_rows($result)){
       ?> <h3>Popular Post</h3><?php
        while($row=mysqli_fetch_assoc($result)){
      ?>
      <a href="./reqblog.php?id=<?php echo $row['id']?>" style="text-decoration: none; color:blue"><?php echo $row['title']?></a><br>
      <?php
      }
    }
    mysqli_close($conn);
    ?>
    </div> 
  </div>

</div>
</div>




<div class="footer">
  <h2>Footer</h2>
</div>

</body>
</html>