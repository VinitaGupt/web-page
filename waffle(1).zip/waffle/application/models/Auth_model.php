<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Auth_Model extends CI_Model
{
  public function checkAuth(){
        $check  = array('userid'=>$this->input->get_request_header('userid', TRUE),'sessionkey'=>$this->input->get_request_header('sessionkey', TRUE));
        if(checkRequired($check)){
            return array('status' => 400,'message'=>"Header Request : ".checkRequired($check),'method'=>$this->method);
        }else{
            $user_id            =   $this->input->get_request_header('userid', TRUE);
            $session_key        =   $this->input->get_request_header('sessionkey', TRUE);
            if($this->Auth_model->checkSession(array('userid'=>$user_id,'session_key'=>$session_key)) != 200){
                return array('status' => 401,'message'=>http_code_message(401),'method'=>$this->method);
            }else{
                return array('status'=>200,'data'=>array('userid'=>$user_id,'session_key'=>$session_key));
            }
        }
    }
  

    public function checkSession($data){
        $check  =   getAnything('users',array('userid'=>$data['userid'],'session_key'=>$data['session_key']),'userid');
        if(count($check)>0){
            return 200;
        }else{
            return 401;
        }
    }
  #_____________________________END____________________________________________#
 
 
 
  public function cheack_auth($data){
        $this->db->where('id',$data['id']);
        $this->db->where('session_key',$data['session_key']);
        return $this->db->get('users')->row_array();  
    }

  public function registerUser($data)
  {
    
    $this->db->insert('users',$data);
    $id= $this->db->insert_id();  //last inserted id
 
   return $this->db->query("SELECT * FROM users WHERE id = ".$id)->row_array();
    //return $this->db->last_query();
    
   
}

//check email  is unique
public function checkemail($email){
    $this->db->where('email',$email);
    $result=$this->db->get('users');
    return $result->num_rows();
}

///cheking the user name is unique
public function checkUserName($userName){
    $this->db->where('username',$userName);
    $result=$this->db->get('users');
    return $result->num_rows();
}
public function update_data($id,$data)
{
    $this->db->where('id',$id);
                  return $this->db->update('users',$data);

}
public function saveData($data)
{
    $this->db->select('*');
    $this->db->from('users');
    $this->db->where(['username' => $data['username'], 'password' =>$data['password']]);
    return $this->db->get()->row_array();
}

public function get_user_by_email($email)
{
       $this->db->select('email');
       $this->db->from('users'); 
       $this->db->where('email', $email); 
       $query=$this->db->get();
       return $query->row_array();
}


   public function insert_token($token) {
    
    $data = array(
       'token' => $token,
    );
    // Check if insert is successful
    $query=$this->db->insert('users',$data);
    if($query){
        return true;
    }else{
        return false;
    }

}
//get single data 
    public function check($cond,$table){
        $this->db->where($cond);
        $result=$this->db->get($table);
        return $result->num_rows();
    }
    
public function checkOtp($data){
    // $this->db->where(['email' => $data['email'], 'otp' =>$data['otp']]);
    // $result=$this->db->get('users');
    // return $result->num_rows();
    $this->db->where('email', $data['email']);
    $this->db->where('otp', $data['otp']);
    $query = $this->db->get('users');
    return  $num_rows = $query->num_rows();
    //print_r($num_rows);
}

public function update_pass($email,$data){
$this->db->where('email',$email);
return $this->db->update('users',$data);
                   
    //  print_r($this->db->last_query()); 
    //  die;
   
}

public function saveotp($email,$data)
{
  $this->db->where('email', $email);
return $this->db->update('users', $data);
}
public function logout($id){
    $this->input->get_request_header('id');
    $this->input->get_request_header('session_key');
    $this->db->where('id',$id);
   return $this->db->update('users',array('device_type'=>'','session_key'=>'','device_token'=>''));

}


public function update_gmail_social_id($id,$data) {

    $this->db->where('id', $id);
  return  $this->db->update('users', $data);
//print_r($this->db->last_query()); 
}


public function insert_gmail_social_id($data)
  {
      $this->db->insert('users',$data);
      $id= $this->db->insert_id();
      $this->db->where('id',$id);
   return  $this->db->get('users')->row_array();
       //print_r($this->db->last_query()); 
    
}
public function update_apple_social_id($id,$data) {

    $this->db->where('id', $id);
   return $this->db->update('users', $data);
}

public function insert_apple_social_id($data)
  {
    $this->db->insert('users',$data);
    $id= $this->db->insert_id();
    $this->db->where('id',$id);
 return  $this->db->get('users')->row_array();
    
}


public function delete($id){
    $this->input->get_request_header('id');
    $this->input->get_request_header('session_key');
    $this->db->where("id",$id);
    return $this->db->delete("users"); 
    // print_r($this->db->last_query()); 
}

public function reset_password($email, $password) {
    $hash = password_hash($password, PASSWORD_DEFAULT); // Don't forget to hash the password before saving it
    $this->db->where('email', $email)
             ->update('users', array('password' => $hash));
}


public function insert($data)

{
  $this->db->insert('doc_verification',$data);
  $id= $this->db->insert_id();  //last inserted id
  $this->db->where('id',$id);
 return $this->db->get('doc_verification')->row_array();  
 //print_r($this->db->last_query()); 
    
}
public function insertimg($data)
{
  $this->db->insert('doc_verification',$data);
  $id= $this->db->insert_id();  //last inserted id
  $this->db->where('id',$id);
 return $this->db->get('doc_verification')->row_array();  
 //print_r($this->db->last_query()); 
    
}
public function checkpassword($data){
    $this->db->where(['email' => $data['email'], 'password' =>$data['password']]);
    $result=$this->db->get('users');
    return $result->num_rows();
    
    // print_r($num_rows);
}

public function chnage_password($password,$data){

    $this->db->where('password',$password);
   return $this->db->update('users',$data);
    //print_r($this->db->last_query());
                   
   
}
public function insertverify($id,$data)

{
    $this->db->where('id',$id);
    $this->db->update('users',$data); 
  $this->db->where('id',$id);
 return $this->db->get('users')->row_array();  
 //print_r($this->db->last_query()); 
    
}



}