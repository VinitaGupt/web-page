
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Reset_Model extends CI_Model
{
    public function get_token($token)
    {
           $this->db->select('token');
           $this->db->from('users'); 
           $this->db->where('token', $token); 
           $query=$this->db->get();
           return $query->row_array();
    }
    public function update_pass($token,$newpass)
  {
    $data = array(
      'password'=> $newpass
      );
    $this->db->where("token", $token);
    $this->db->update("users",$data);
    return  true;
  }
  
}
?>