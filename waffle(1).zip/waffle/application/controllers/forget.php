<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Forget extends CI_Controller
{
  public function __construct()
  {
      parent::__construct();
      $this->load->database();
      $this->load->model('forget_model');
      $this->load->helper('otp');
      $this->load->helper('utc');
  }

  public function ForgotPassword()
  {
        $email = $this->input->post('email');      
        $findemail = $this->forget_model->ForgotPassword($email);  
        if(generateOtp($findemail)){
         $this->forget_model->sendpassword($findemail);        
          }else{
            

       
     }
  }



}
?>