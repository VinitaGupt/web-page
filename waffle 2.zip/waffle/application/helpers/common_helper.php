<?php
//check validation 
function checkRequired($array){
        $requried = "";
        foreach($array as $key => $value) {
            if ($value==''){
                $requried .= $key.',';
            }
        }
        if($requried!=""){
            return rtrim($requried,',') . ' filed is required';
        }
        else{
            return false;
        }
}

function checkEmailFormat($email){
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
       return 1;
     } else {
     return 0;
     }
}

//otp_helper

//function for otp 4 degit 
function generateOtp() {
    $otp = rand(1000, 9999);
   return $otp;
   }
  
//phpmailer_helper

function send($mail,$email_to,$subject,$message){         
    // SMTP configuration
$mail->isSMTP();
 $mail->Host = 'smtp.gmail.com';
 $mail->SMTPAuth = true; 
 $mail->Username = 'zargam.techwinlabs@gmail.com';
 $mail->Password = 'gkfckkdkawethkmm';
 $mail->SMTPSecure = 'ssl';
 $mail->Port = 465;
 $mail->setFrom('vikas.techwinlabs@gmail.com', 'betterPainting');
 $mail->addReplyTo('vikas.techwinlabs@gmail.com', 'betterPainting');
 $mail->addAddress($email_to);


    // Add a recipient

    // Add cc or bcc 
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    // Email subject
    $mail->Subject = $subject;

    // Set email format to HTML
    $mail->isHTML(true);

    // Email body content
    $mailContent =$message;
    $mail->Body = $mailContent;

    // Send email
    if(!$mail->send()){
        //echo 'Message could not be sent.';
        //echo 'Mailer Error: ' . $mail->ErrorInfo;
    }else{
        //echo 'Message has been sent';
    }
}

//session helper

function randomString()
{
   $str = rand();
    $result = md5($str);
   return $result;
}


//utc_helper
//provide time utc for crated at
function utcTime(){
    $time = new DateTime('now', new DateTimeZone('UTC'));
    return $time->format('Y-m-d H:i:s');
    //return $time->format('F j, Y H:i:s');
    }


    //document verification 
// function uploadImage($side)
//     {
//        if($side == 1){ #-----front upload ---#
   
//            $destinationPath = './assest/upload';
//            $tmpName = $_FILES['image']['tmp_name'];
//            $fileName = rand(1111, 9999)  . $_FILES['image']['name'];
//        }
   
//        if($side == 2){ #----- back upload ---#
//            $destinationPath = './assest/upload';
//            $tmpName = $_FILES['image']['tmp_name'];
//            $fileName = rand(1111, 9999)  . $_FILES['image']['name'];
//        } 
   
//      move_uploaded_file($tmpName, $destinationPath.'/'.$fileName);
//     return $fileName;
//     }




    
   






?> 

       






    