<?php
defined ('BASEPATH') or exit('No direct script access allowed');

class common_model extends CI_Model
{


    //get single data 
    public function check($cond,$table){
        $this->db->where($cond);
        $result=$this->db->get($table);
        return $result->num_rows();
    }   


   // get multiple data
   public function getData($id)
   {
       $this->db->select('*');
       $this->db->from('users');
       $this->db->where('id', $id);
       return $this->db->get()->row_array();
   }
   

public function verify_otp($email,$otp)
{
    $this->db->from('users');
    $this->db->where(['email'=>$email, 'otp'=>$otp]);
    return $this->db->get()->row_array();
    
}



// public function saveotp($otp)
// {
//   $this->db->insert('users',$otp);
//   $query=$this->db->get('users')->row_array();
  
//   if(!empty($query)){
//       return $query;
//   }else{
//       return false;
//   }
// }





public function saveotp($email,$data)
{
  $this->db->where('email', $email)
                    ->update('users', $data);
}

public function updatePassword($data,$otp)
{
  $this->db->where('otp', $otp)
                    ->update('users', $data);
}


public function update_social_id($email,$data)
{
  $this->db->where('email', $email)
                    ->update('users', $data);
}

   

}
?>