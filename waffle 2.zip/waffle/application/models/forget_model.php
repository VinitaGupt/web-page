<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Forget_model extends CI_Model
{


    
    public function ForgotPassword($email)
    {
           $this->db->select('email');
           $this->db->from('users'); 
           $this->db->where('email', $email); 
           $query=$this->db->get();
           return $query->row_array();
    }
    public function sendpassword(){
        
    }
    
}