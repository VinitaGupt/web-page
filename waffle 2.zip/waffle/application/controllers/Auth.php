<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

class Auth extends REST_Controller
{
    private $Authentication	= 	array('social_login','login','signupCustomer');

    public function __construct()
    {
        parent::__construct();

        $this->load->model('Auth_model');
        $this->load->model('common_model');
        $this->load->helper('common');
        $this->load->database();


        $get_req =	$this->uri->segment(1);
		if(!empty($get_req) && $get_req!==NULL){
			
				$data=$this->Auth_model->checkAuth();
				if($data){
                    $this->response(['status' => 200, 'message' => 'Registration successfully.', 'data' => ''], REST_Controller::HTTP_OK);
				}else{
					$id=$this->input->get_request_header('userid', TRUE);
                    $session_key=$this->input->get_request_header('sessionkey', TRUE);
				}
			}else{
            $this->response(['status' => 400, 'message' => 'plaese enter valid device_type'], Rest_Controller::HTTP_BAD_REQUEST);
		}
	}
    
    #____________LOGIN API __________________#

    public function login_post()
    {

        $input = $this->input->post();


        $check_validation = array('username' => @$input['username'], 'password' => @$input['password'], 'session_key' => randomString());
        //checkRequired($check_validation);

        if (checkRequired($check_validation)) {
            $result =     array('status' => 400, 'message' => checkRequired($check_validation) . " are requied fields.");
            $this->response($result, $result['status']);
        } else {

            $data  = array('username' => @$input['username'], 'password' => md5(@$input['password']));


            $result = $this->Auth_model->saveData($data);

            $input = $this->input->post();
            $id = @$input['id'];

            $data = array(
                'session_key' => randomString()
            );

            $update = $this->Auth_model->update_data($id, $data);

            if (empty($update)) {
                $this->response(['status' => 400, 'message' => 'update failed']);
            } else {

                if (empty($result)) {
                    $this->response(['status' => 400, 'message' => 'username/password is wrong']);
                } else {

                    $this->response(['status' => 200, 'message' => 'login successfully.', 'data' => $result], REST_Controller::HTTP_OK);
                }
            }
        }
    }
    #_______________________ E N D _________________________#




    #____________Register API __________________#
    //register user
    public function Register_post()
    {
        $input    = $this->input->post();
        $check_validation = array('username' => @$input['username'], 'email' => @$input['email'], 'password' => @$input['password'], 'role' => @$input['role'], 'phone' => @$input['phone'], 'device_type' => @$input['device_type'], 'device_token' => @$input['device_token']);
        //checkRequired($check_validation);
        if (checkRequired($check_validation)) {
            $result  =     array('status' => 400, 'message' => checkRequired($check_validation) . "");
            $this->response($result, $result['status']);
        } else {

            $role = @$input['role'];
            if (empty($role == 1 || $role == 2)) {
                $this->response(['status' => 400, 'message' => 'plaese enter valid role'], Rest_Controller::HTTP_BAD_REQUEST);
            }
            $device_type = @$input['device_type'];
            if (empty($device_type == 1 || $device_type == 2)) {
                $this->response(['status' => 400, 'message' => 'plaese enter valid device_type'], Rest_Controller::HTTP_BAD_REQUEST);
            }

            $checkEmail = checkEmailFormat($input['email']);
            //$result = $this->Auth_model->checkEmail($checkEmail);
            if (empty($checkEmail)) {
                $this->response(['status' => 400, 'message' => 'Enter valid email']);
            } else {
                // print_r($checkEmail)
                //userName unique
                $userName = @$input['username'];
                $result = $this->Auth_model->checkUserName($userName);
                if (!empty($result)) {
                    $this->response(['status' => 400, 'message' => 'Username is already exist']);
                } else {

                    //used md5
                    $data = array('username' => @$input['username'], 'email' => @$input['email'], 'password' => md5(@$input['password']), 'role' => @$input['role'], 'phone' => @$input['phone'], 'device_type' => @$input['device_type'], 'device_token' => @$input['device_token'], 'session_key' => randomString());

                    $result = $this->Auth_model->registerUser($data);
                    //$intValue = intval($result);


                    $this->response(['status' => 200, 'message' => 'Registration successfully.', 'data' => $result], REST_Controller::HTTP_OK);
                }
            }
        }
    }
    #_______________________ E N D _________________________#



    #____________Forget API __________________#
    //forget password
    public function forget_password_post()
    {

        $this->load->library('phpmailer_lib'); // Load PHPMailer library
        $input = $this->input->post();

        $type = @$input['type'];
        if ($type == 1) {
            $check_validation = array('email' => @$input['email']);
            $this->load->model('common_model');
            $email = $this->input->post('email');
            $user = $this->common_model->check(['email' => $email], "users");
            $otp = rand(1000, 9999);
            $mail = $this->phpmailer_lib->load();
            $email_to = $email;
            $data['otp'] = $otp;
            $subject = 'Reset Password';
            $message = $this->load->view('forget_password', $data, true);
            send($mail, $email_to, $subject, $message);
            if (empty($user)) {
                $this->response(['status' => 400, 'message' => '']);
            } else {
                $data = array(
                    'otp' => $otp,
                    'otp_at' => utcTime()
                );

                $this->common_model->saveotp($email, $data);

                $this->response(['status' => 200, 'message' => 'Kindly review your email to obtain the OTP'], REST_Controller::HTTP_OK);
            }
        } elseif ($type == 2) {


            $email = $this->input->post('email');
            $otp = $this->input->post('otp');
            $data = array(
                'otp' => $otp,
                'email' => $email
            );



            $user = $this->Auth_model->checkOtp($data);
            // print_r($user);die;

            if (empty($user)) {
                $this->response(['status' => 400, 'message' => 'email/otp can not  match'], Rest_Controller::HTTP_BAD_REQUEST);
            } else {

                $this->response(['status' => 200, 'message' => 'verify email and otp'], REST_Controller::HTTP_OK);
            }
        } elseif ($type == 3) {


            $email = $this->input->post('email');
            $newpass = $this->input->post('newpass');

            $data = array(

                'password' => md5($newpass)
            );

            $password = $this->Auth_model->update_pass($email, $data);
            // print_r($password);

            if (empty($password)) {
                $this->response(['status' => 400, 'message' => 'try again']);
            } else {
                $this->response(['status' => 200, 'message' => 'password upadted'], REST_Controller::HTTP_OK);
            }
        }
    }
    #_______________________ E N D _________________________#





    #____________logout API __________________#
    public function logout_post()
    {
        $id = $this->input->post('id');
        $this->load->model('Auth_model');
        $result = $this->Auth_model->logout($id);

        if (empty($result)) {
            $this->response(['status' => 400, 'message' => 'failed logout']);
        } else {

            $this->response(['status' => 200, 'message' => 'Logout successfully.', 'sucess' => 1], REST_Controller::HTTP_OK);
        }
    }

    #_______________________ E N D _________________________#



    #____________Delete API __________________#
    public function delete_delete()
    {
        $id = $this->input->get('id');
        $this->load->model('Auth_model');
        $result = $this->Auth_model->delete($id);
        if (empty($result)) {
            $this->response(['status' => 400, 'message' => 'delete']);
        } else {
            $this->response(['status' => 200, 'message' => 'delete record  successfully.', 'sucess' => 1], REST_Controller::HTTP_OK);
        }
    }
    #_______________________ E N D _________________________#



    #__________  S O C I A L	L O G I N	________________#


    public function social_login_post()
    {

        $input = $this->input->post();
        $social_type = @$input['social_type'];
        if ($social_type == 1) {
            $check_validation = array('device_type' => @$input['device_type'], 'social_type' => @$input['social_type'], 'device_token' => @$input['device_token']);
            if (checkRequired($check_validation)) {
                $result = $this->response(['status' => 400, 'message' => checkRequired($check_validation)], Rest_Controller::HTTP_BAD_REQUEST);
                $this->response($result, $result['status']);
            } else {
                $this->load->model('common_model');
                $social_id = $this->input->post('gmail_social_id');
                $user = $this->common_model->check(['gmail_social_id' => $social_id], "users");
                if (empty($user)) {
                    //social id exist than update social id
                    $social_id = $this->input->post('gmail_social_id');
                    $id = $this->input->post('id');
                    $data = array(
                        'gmail_social_id' => $social_id,
                        'session_key' => randomString(),
                    );
                    // print_r($data);
                    // die();
                    $update  = $this->Auth_model->update_gmail_social_id($id, $data);
                    if (empty($update)) {
                        $this->response(['status' => 400, 'message' => ' plaese try again']);
                    } else {
                        $this->response(['status' => 200, 'message' => 'login successfully.', 'data' => $update], REST_Controller::HTTP_OK);
                    }
                } else {

                    $this->load->model('common_model');
                    $data = $this->input->post();
                    // $email = $this->input->post('email');
                    //$user = $this->common_model->check(['data' => $data], "users");

                    if (isset($data) && !empty($data)) {
                        $social_id = $this->input->post('gmail_social_id');

                        $data = array(
                            'gmail_social_id' => $social_id,
                            'session_key' => randomString(),
                            'device_type' => @$data['device_type'],
                            'device_token' => @$data['device_token'],
                            //  'email' =>  @$data['email'],
                            // 'username' => $data['username']
                        );
                        $result = $this->Auth_model->insert_gmail_social_id($data);
                        if (empty($result)) {
                            $this->response(['status' => 400, 'message' => 'try again']);
                        } else {

                            $this->response(['status' => 200, 'message' => 'login successfully.', 'data' => $result], REST_Controller::HTTP_OK);
                        }
                    }
                }
            }
        }

        if ($social_type == 2) {

            $check_validation = array('device_type' => @$input['device_type'], 'social_type' => @$input['social_type']);
            if (checkRequired($check_validation)) {
                $result = $this->response(['status' => 400, 'message' => checkRequired($check_validation)], Rest_Controller::HTTP_BAD_REQUEST);
                $this->response($result, $result['status']);
            } else {
                $this->load->model('common_model');
                $social_id = $this->input->post('apple_social_id');
                $user = $this->common_model->check(['apple_social_id' => $social_id], "users");
                if (!empty($user)) {
                    //social id exist than update social id
                    $social_id = $this->input->post('apple_social_id');
                    $id = $this->input->post('id');

                    $data = array(
                        'apple_social_id' => $social_id,
                        'session_key' => randomString(),
                    );
                    $update  = $this->Auth_model->update_apple_social_id($id, $data);


                    if (empty($update)) {
                        $this->response(['status' => 400, 'message' => ' plaese try again']);
                    } else {
                        $this->response(['status' => 200, 'message' => 'login successfully.', 'data' => $update], REST_Controller::HTTP_OK);
                    }
                } else {

                    $this->load->model('common_model');
                    $data = $this->input->post();
                    // $email = $this->input->post('email');
                    // $user = $this->common_model->check(['email' => $email], "users");
                    if (isset($data) && !empty($data)) {

                        $check_validation = array('username' => @$data['username'], 'email' => @$data['email']);
                        if (checkRequired($check_validation)) {
                            $result = $this->response(['status' => 400, 'message' => checkRequired($check_validation)], Rest_Controller::HTTP_BAD_REQUEST);
                            $this->response($result, $result['status']);
                        } else {

                            $social_id = $this->input->post('apple_social_ids');

                            $data = array(
                                'apple_social_id' => $social_id,
                                'session_key' => randomString(),
                                'email' =>  @$data['email'],
                                'username' => $data['username']
                            );
                            $result = $this->Auth_model->insert_apple_social_id($data);
                            if (empty($result)) {
                                $this->response(['status' => 400, 'message' => 'try again']);
                            } else {

                                $this->response(['status' => 200, 'message' => 'login successfully.', 'data' => $result], REST_Controller::HTTP_OK);
                            }
                        }
                    }
                }
            }
        }
    }


    #__________  DOCUMENT VERIFICATION	________________#

    public function document_verification_post()
    {
        $input = $this->input->post();
        $type = @$input['type'];

        if (empty($type == 1 || $type == 2 || $type == 3)) {
            $this->response(['status' => 400, 'message' => 'plaese enter valid type'], Rest_Controller::HTTP_BAD_REQUEST);
        }
        if ($type == 1) {
            $check_validation = array('type' => @$input['type'], 'image1' => @$_FILES['image1'], 'image2' => @$_FILES['image2']);
            if (checkRequired($check_validation)) {
                $result = $this->response(['status' => 400, 'message' => checkRequired($check_validation)], Rest_Controller::HTTP_BAD_REQUEST);
                $this->response($result, $result['status']);
            } else {

                // front_image

                if (!empty(@$_FILES['image1']['name'])) {

                    $config['upload_path']  = './uploads/';
                    $config['allowed_types'] = 'gif|jpeg|png|jpg';
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);

                    if (!$this->upload->do_upload('image1')) {
                        //$error = array('error' => $this->upload->display_errors());
                        $this->response(['status' => 400, 'message' => 'please upload image', 'data' => NULL], Rest_Controller::HTTP_BAD_REQUEST);
                    } else {
                        $imagef = $this->upload->data();

                        $front_image = $imagef['file_name'];
                        $data = array(
                            "type" => $input['type'],
                            "side" => 1,
                            "image" => $front_image,

                        );
                        // print_r($data);
                        // die();
                        $result = $this->Auth_model->insert($data);
                    }
                }
                //back_image
                if (!empty(@$_FILES['image2']['name'])) {

                    $config['upload_path']  = './uploads/';
                    $config['allowed_types'] = 'gif|jpeg|png|jpg';
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);

                    if (!$this->upload->do_upload('image2')) {
                        //$error = array('error' => $this->upload->display_errors());
                        $this->response(['status' => 400, 'message' => 'please upload image', 'data' => NULL], Rest_Controller::HTTP_BAD_REQUEST);
                    } else {
                        $imagef = $this->upload->data();

                        $back_image = $imagef['file_name'];
                        $data = array(
                            "type" => $input['type'],
                            "side" => 2,
                            "image" => $back_image,
                        );
                        // print_r($data);
                        // die();

                        $Insert = $this->Auth_model->insertimg($data);
                    }
                }
                $this->response(['status' => 200, 'message' => 'upload document successfully.',], REST_Controller::HTTP_OK);
            }
        } elseif ($type == 2) {
            $check_validation = array('type' => @$input['type'], 'image1' => @$_FILES['image1'], 'image2' => @$_FILES['image2']);
            if (checkRequired($check_validation)) {
                $result = $this->response(['status' => 400, 'message' => checkRequired($check_validation)], Rest_Controller::HTTP_BAD_REQUEST);
                $this->response($result, $result['status']);
            } else {

                // front_image

                if (!empty(@$_FILES['image1']['name'])) {

                    $config['upload_path']  = './uploads/';
                    $config['allowed_types'] = 'gif|jpeg|png|jpg';
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);

                    if (!$this->upload->do_upload('image1')) {
                        //$error = array('error' => $this->upload->display_errors());
                        $this->response(['status' => 400, 'message' => 'please upload image',], Rest_Controller::HTTP_BAD_REQUEST);
                    } else {
                        $imagef = $this->upload->data();

                        $front_image = $imagef['file_name'];
                        $data = array(
                            "type" => $input['type'],
                            "side" => 1,
                            "image" => $front_image,

                        );
                        // print_r($data);
                        // die();
                        $this->Auth_model->insert($data);
                    }
                }
                //back_image
                if (!empty(@$_FILES['image2']['name'])) {

                    $config['upload_path']  = './uploads/';
                    $config['allowed_types'] = 'gif|jpeg|png|jpg';
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);

                    if (!$this->upload->do_upload('image2')) {
                        //$error = array('error' => $this->upload->display_errors());
                        $this->response(['status' => 400, 'message' => 'please upload image',], Rest_Controller::HTTP_BAD_REQUEST);
                    } else {
                        $imagef = $this->upload->data();

                        $back_image = $imagef['file_name'];



                        $data = array(
                            "type" => $input['type'],
                            "side" => 2,
                            "image" => $back_image,
                        );
                        // print_r($data);
                        // die();

                        $Insert = $this->Auth_model->insertimg($data);
                    }
                }
                //$this->response(['status' => 200, 'message' => 'upload document successfully.', ], REST_Controller::HTTP_OK);

            }
        } elseif ($type == 3) {
            $check_validation = array('type' => @$input['type'], 'image1' => @$_FILES['image1'], 'image2' => @$_FILES['image2']);
            if (checkRequired($check_validation)) {
                $result = $this->response(['status' => 400, 'message' => checkRequired($check_validation)], Rest_Controller::HTTP_BAD_REQUEST);
                $this->response($result, $result['status']);
            } else {

                // front_image

                if (!empty(@$_FILES['image1']['name'])) {

                    $config['upload_path']  = './uploads/';
                    $config['allowed_types'] = 'gif|jpeg|png|jpg';
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);

                    if (!$this->upload->do_upload('image1')) {
                        //$error = array('error' => $this->upload->display_errors());
                        $this->response(['status' => 400, 'message' => 'please upload image'], Rest_Controller::HTTP_BAD_REQUEST);
                    } else {
                        $imagef = $this->upload->data();

                        $front_image = $imagef['file_name'];
                        $data = array(
                            "type" => $input['type'],
                            "side" => 1,
                            "image" => $front_image,

                        );
                        // print_r($data);
                        // die();
                        $this->Auth_model->insert($data);
                    }
                }
                //back_image
                if (!empty(@$_FILES['image2']['name'])) {

                    $config['upload_path']  = './uploads/';
                    $config['allowed_types'] = 'gif|jpeg|png|jpg';
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);

                    if (!$this->upload->do_upload('image2')) {
                        //$error = array('error' => $this->upload->display_errors());
                        $this->response(['status' => 400, 'message' => 'please upload image'], Rest_Controller::HTTP_BAD_REQUEST);
                    } else {
                        $imagef = $this->upload->data();

                        $back_image = $imagef['file_name'];



                        $data = array(
                            "type" => $input['type'],
                            "side" => 2,
                            "image" => $back_image,
                        );
                        // print_r($data);
                        // die();

                        $Insert = $this->Auth_model->insertimg($data);
                    }
                }
                $this->response(['status' => 200, 'message' => 'upload document successfully.',], REST_Controller::HTTP_OK);
            }
        }
    }
    #_______________________ E N D _________________________#



    #__________  CHANGE PASSWORD	________________#

    public function change_password_post()
    {
        $input = $this->input->post();

        $data  = array('password' => @$input['password'],);
        if (checkRequired($data)) {
            $this->response(['status' => 400, 'message' => 'please enter email & old password'], Rest_Controller::HTTP_BAD_REQUEST);
        } else {

            $email = $this->input->post('email');
            $currentpassowrd = $this->input->post('password');
            $data = array(
                'email' => $email,
                'password' => md5($currentpassowrd)
            );

            $user = $this->Auth_model->checkpassword($data);
            // print_r($user);die;

            if (empty($user)) {
                $this->response(['status' => 400, 'message' => 'email/password  can not  match'], Rest_Controller::HTTP_BAD_REQUEST);
            } else {
                $input = $this->input->post();

                $data  = array('newpassword' => @$input['newpassword'], 'Cpassword' => @$input['Cpassword']);
                if (checkRequired($data)) {
                    $this->response(['status' => 400, 'message' => 'Your old password match, please enter new password & Cpassword password'], Rest_Controller::HTTP_BAD_REQUEST);
                } else {

                    $newpass = $input['newpassword'];
                    $Cpassword = $input['Cpassword'];
                    if (empty($newpass == $Cpassword)){
                        $this->response(['status' => 400, 'message' => 'newpassword & Cpassword does not match'], Rest_Controller::HTTP_BAD_REQUEST);
                    } else {
                        $password = md5($input['password']);
                        $newpass = $input['newpassword'];

                        $data = array(

                            'password' => md5($newpass)
                        );


                        $result = $this->Auth_model->chnage_password($password, $data);
                        // print_r($password);
                        if (empty($result)) {
                            $this->response(['status' => 400, 'message' => 'try again']);
                        } else {
                            $this->response(['status' => 200, 'message' => 'password change successfully'], REST_Controller::HTTP_OK);
                        }
                    }
                }
            }
        }
    }

    #_______________________ E N D _________________________#
}
