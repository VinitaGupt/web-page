<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Reset extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('reset_model');
    }
   

public function index()
{
     $token =$this->input->get('token');

    // $data['token']=$this->reset_model->get_token($token);/
   
    $this->load->view('reset_password',compact('token'));
}
public function resetPassword(){
    
    $token = $this->uri->segment(2);
    

    $data =$this->input->post();
    // print_r($data);
    // die;
    // $data['token']=$this->reset_model->get_token($token);
  

    if (isset($data) && !empty($data)) {
         
      
        $this->load->library('form_validation');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('c_password', 'Confirm password', 'required|matches[password]');
        if ($this->form_validation->run() == FALSE) {
         return $this->load->view("reset_password",compact('token'));
        }     
        $newpass = $this->input->post('newpass');
        $this->reset_model->update_pass($token, array('password' => md5($newpass)));
        
    }
 
       


}



}
  
   
