<?php
include "config.php";
session_start(); 
$email=$_SESSION['email'];

$id=$_GET['id'];

 
$sql="update users set block=0 where id=$id";
if(mysqli_query($conn,$sql)){
    header('location:admin.php');
    exit();
}else{

}



?>