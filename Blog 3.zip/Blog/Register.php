<?php
include "config.php";
if(isset($_POST['register'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $mobile=$_POST['mobile'];
    $utype=$_POST['utype'];

    //email duplicate
    $sqll="select * from users where email='$email'";
$result=mysqli_query($conn,$sqll);
 if(mysqli_num_rows($result)>0){
    echo"Duplicate";
}else{
    $sql= "INSERT INTO users (name,email,mobile,password,role) 
    values('$name','$email','$mobile','$password','$utype')"; //insert record
     if(mysqli_query($conn,$sql)){
        echo "inserted";
     }else{
        echo"failed";
     }


    }
}
// login relocate
if(isset($_POST['login'])){
    header('location: ./login.php');
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentd</title>
    <link rel="stylesheet" href="./style.css">
    
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
      </script>
    <script src=
"https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js">
      </script>
    <script src=
"https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js">
      </script>
      <style>
        .error{
    color:red !important;
  }
      </style>
</head>
<body>
    <form id="signupForm" action="" method="post">
    <div class="container">
        <div class="row">
            <div class="col">
           <h2>Register Page</h2>
           </div>
           <div class="coll">
            <label for="">Name</label>
            <input type="text" name="name" class="form-control">
           </div>
           <div class="coll">
            <label for="">email</label>
            <input type="text" name="email" class="form-control">
           </div>
           <div class="col-mb-3">
            <label for="">Password</label>
            <input type="text" name="password" class="form-control">
           </div>
           <div class="col-mb-3">
            <label for="">Mobile</label>
            <input type="text" name="mobile" class="form-control">
           </div>
           <div class="col-mb-3">
            <label for="">User</label>
            <input type="radio" value="0" name="utype">
            <label for="">Admin</label>
            <input type="radio" value="1" name="utype">
           </div>

        </div>
        <div class="button">
        <button type="submit" name="register">Register</button> 
        
        <a href="login.php" class="logbtn">login</a>
        </div> 
    </div>
    </form>

</body>
</html>
<script>
    //validation
        $().ready(function () {
 
            $("#signupForm").validate({
                rules: {
                    name: "required",  
                        required: true,
                       
                    password: {
                        required: true,
                        minlength: 5
                    },
                    
                    email: {
                        required: true,
                        email: true
                    },
                    utype: {
                        required: true,
                        
                    },

                    agree: "required"
                },
                // In 'messages' user have to specify message as per rules
                messages: {
                    name: " Please enter your name",
                    email:{
                        required:"Email is mandatory",
                        email:"Please enter correct email id"
                    },
                    
                    password: {
                        required: " Please enter a password",
                        minlength:
                      " Your password must be consist of at least 5 characters"
                    },

                    utype: {
                        required: " Please select any one",
                        
                    },
                }
            });
        });
</script>

