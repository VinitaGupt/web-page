<?php

include "config.php";

session_start(); 
$email=$_SESSION['email'];

$sql="select * from users where email='$email'";
   $result=mysqli_query($conn,$sql);
   if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
       $id=$row['id'];
    }
   }

 $encrypt=(($title*12345678*5678)/9765435);
 $url="title=".urlencode(base64_encode($encrypt));
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
    <style>
        nav{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 100vw;
            height: 7vh;
            background-color: black;
            color: white;
           
        }
        .left{
            width: 80%;
            height: 100%;
            /* font-size: 10%; */
        }
        .left ul{
           padding-right:0%;
           padding-left: 10%;
        }
        .right{
            width: 20%;
            height: 100%;
            display: flex;
            flex-direction: row;
            justify-content: right;
            margin-right: 2%;
        }
        .left a{
            color: white;
            /* font-size: larger; */
        } 
        .left ul li a{
            font-size: 16px;
        }
        .right a{
            margin-top: 4%;
            color: white;
            margin-right: 50%;
            font-size: 16px;
        }
        nav .left ul li{
            display: inline-block;
            margin-left: 10%;
            flex-direction: row;
            color:white;
            padding-top: 10px;
            font-size: 10px;
        }
        .container{
            padding:8%;

        }
    </style>
</head>
<body>
<nav>
        <div class="left">     
        <ul>
             <li><a href="./admin.php">User</a></li>
             <li><a href="./blog.php.php">Blog</a></li>
        </ul>
        </div>
        <div class="right">
        <a href="logout.php">Logout</a>
        </div>
    </nav>
  
    
    <div class="container">

        <form action="" method="get">
    <select name="user" id="userid">
        <option value="">Userid</option>
       <?php
       $sql="select * from addblog";
       $result=mysqli_query($conn,$sql);
       if(mysqli_num_rows($result)){
        while($row=mysqli_fetch_assoc($result)){



       ?>
        <option <?=  (isset($_REQUEST['user'])  &&  $_REQUEST['user'] == $row['uploade_id'])  ? 'selected' : ''  ?> value="<?php echo $row['uploade_id'];?>"><?php echo $row['uploade_id'];?></option>
        <?php
         }
        }
        ?>
        </select>
        
      
        <select name="title" id="title">
        <option value="">Title</option>
       <?php
       $sql="select * from addblog";
       $result=mysqli_query($conn,$sql);
       if(mysqli_num_rows($result)){
        while($row=mysqli_fetch_assoc($result)){
       ?>
        <option <?=  (isset($_REQUEST['title'])  &&  $_REQUEST['title'] == $row['title'])    ? 'selected' : ''  ?> value="<?php echo $url; ?><?php echo  $row['title'];?>"><?php echo $row['title'];?></option>
        <?php
         }
        }
        ?>
        </select>

        <div class="button">
         <button type="submit" name="submit" value="search">Find</button>
         </div>
    </form>

    <?php
//    $sql="select * from users where id='$id'";
//    $result=mysqli_query($conn,$sql);
//    if(mysqli_num_rows($result)>0){
//     while($row=mysqli_fetch_assoc($result)){
//        $name=$row['name'];
       
//     }
//    }
   ?>
       <table class="table">
        <thead class="thead-dark">
       <tr style="text-align: center;">
       <th>Title</th>
       <th>Subject</th>
       <th>Posted by</th>
       <th colspan="2">Operations</th>
       </tr>
        </thead>

        <?php
        if(isset($_REQUEST['submit'])){
            $title=$_REQUEST['title'];
            $user=$_REQUEST['user'];

//             $sql="select * from users where id=$user";
//             $result=mysqli_query($conn,$sql);
//             if(mysqli_num_rows($result)>0){
//                 while($row=mysqli_fetch_assoc($result)){
                 
//                     $namee=$row['name'];
                   
       
//     }
//    }
        //   $sqll="select * from addblog where id =$id or title='$title' ";

        
          $sqll="SELECT addblog.title,addblog.subject,users.user_name FROM addblog 
           INNER JOIN users ON users.id=addblog.uploade_id AND title='$title' AND uploade_id='$user'";
          $result=mysqli_query($conn,$sqll);
          if(mysqli_num_rows($result)){
            while($row=mysqli_fetch_assoc($result)){
        ?>
            <tr style="text-align: center;"> 
                <td scope="row"><?php echo $row['title'];?></td>
                <td scope="row"><?php echo $row['subject'];$id=$row['uploade_id'];?></td>
                <td scope="row"><?php echo $row['user_name'];?></td>
                
                <td>
                    <form action="" method="post">
                    <select name="adminside" id="">
                        <option value="1">Keep</option>
                        <option value="0">Ban</option>
                    </select>
                    </form>
                </td>
              
              
            </tr>
      <?php
        }
          }
        }
      ?>


       </table>
    </div>
 </div>

</body>
</html>

