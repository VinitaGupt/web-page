<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Curd</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assest/css/bootstrap.min.css">
    <style>
  .mask-custom {
    backdrop-filter: contrast(140%) brightness(100%) saturate(100%) sepia(50%) hue-rotate(0deg) grayscale(0%) invert(0%) blur(0px);
    mix-blend-mode: lighten;
    background: rgba(161, 44, 199, 0.31);
    opacity: 1;
  }
</style>

</head>
<body>
<div class="container">
    <div class="row">
    <div
  class="bg-image"
  style="
    background-image: url('/image/dating.jpeg');
    height: 100vh;
  "
>
  <div class="mask mask-custom"></div>
</div>
    </div>

</div>
</body>
</html>