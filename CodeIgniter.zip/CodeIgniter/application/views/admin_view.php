<!DOCTYPE html>
<html>
<head>
    <title>Admin Page</title>
</head>
<body>
    <h1>Welcome to the Admin Page!</h1>
    <p>This is the protected admin area.</p>
    <a href="<?php echo base_url('login/logout'); ?>">Logout</a>
</body>
</html>
