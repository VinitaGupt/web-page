<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
</head>
<body>
    <h1>Login</h1>
    <?php echo validation_errors(); ?>
    <?php if (isset($error)) echo '<p>'.$error.'</p>'; ?>
    <?php echo form_open('login/validate_login'); ?>
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>

        <input type="submit" value="Login">
    </form>
</body>
</html>
