<?php


class Curd extends CI_controller
{
    public function index()
    {
        $this->load->view('home_view');
    }
}


?>