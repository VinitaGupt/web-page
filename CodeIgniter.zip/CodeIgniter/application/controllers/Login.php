<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function index() {
        $this->load->view('login_view');
    }

    public function validate_login() {
        // Add validation rules for the login form
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            // If validation fails, load the login_view again
            $this->load->view('login_view');
        } else {
            // Validation successful, check the user's credentials in the database
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            // Replace 'users' with the actual table name you created
            $this->load->model('login_model');
            $user = $this->login_model->get_user($username, $password);

            if ($user) {
                // Set session data and redirect to admin page
                $this->session->set_userdata('user_id', $user['id']);
                redirect('admin');
            } else {
                // If user not found or invalid credentials, show error message
                $data['error'] = 'Invalid username or password.';
                $this->load->view('login_view', $data);
            }
        }
    }

    public function logout() {
        // Clear the user's session data and redirect to login page
        $this->session->unset_userdata('user_id');
        redirect('login');
    }
    
}
?>